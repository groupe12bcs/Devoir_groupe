
import java.util.Scanner;

public class ConvertisseurTemperature {

    public static void main(String[] args) {
        Scanner saisie = new Scanner(System.in);

        System.out.println("Choisissez une option :");
        System.out.println("1. Convertir de Celsius à Fahrenheit");
        System.out.println("2. Convertir de Fahrenheit à Celsius");
        int choix = saisie.nextInt();

        if (choix == 1) {
            System.out.print("Entrez la température en Celsius : ");
            double celsius = saisie.nextDouble();
            double fahrenheit = convertirCelsiusEnFahrenheit(celsius);
            System.out.println(celsius + " degrés Celsius équivalent à " + fahrenheit + " degrés Fahrenheit.");
        } else if (choix == 2) {
            System.out.print("Entrez la température en Fahrenheit : ");
            double fahrenheit = saisie.nextDouble();
            double celsius = convertirFahrenheitEnCelsius(fahrenheit);
            System.out.println(fahrenheit + " degrés Fahrenheit équivalent à " + celsius + " degrés Celsius.");
        } else {
            System.out.println("Choix invalide.");
        }
    }

    public static double convertirCelsiusEnFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    public static double convertirFahrenheitEnCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }
}





