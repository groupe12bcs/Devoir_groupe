import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {

        System.out.println("Donner la longueur");
        Scanner longueur = new Scanner(System.in);
        int L = longueur.nextInt();
        System.out.println("Donner la largeur");
        Scanner largeur = new Scanner(System.in);
        int la = largeur.nextInt();
        int su = L* la;
        System.out.println("la surface est :"+su);
    }
}