import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {
        System.out.println("donner trois nombres");
        Scanner saisie = new Scanner(System.in);
        float a = saisie.nextFloat();
        float b = saisie.nextFloat();
        float c = saisie.nextFloat();
        float moy = (a + b + c)/3;
        System.out.println("la moyenne de ces trois nombres est :"+moy);
    }
}