import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {

        System.out.println("donner un nombre");
        Scanner saisie = new Scanner(System.in);
        int nb = saisie.nextInt();
        int c = nb * nb;
        System.out.println("le carré est :"+c);
    }
}