
import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez une année : ");
        int annee = scanner.nextInt();

        if (estBissextile(annee)) {
            System.out.println(annee + " est une année bissextile.");
        } else {
            System.out.println(annee + " n'est pas une année bissextile.");
        }

        scanner.close();
    }

    static boolean estBissextile(int annee) {

        if (annee % 4 != 0) {
            return false;
        }

        else if (annee % 100 != 0) {
            return true;
        }

        else if (annee % 400 != 0) {
            return false;
        }
        else {
            return true;
        }
    }
}
