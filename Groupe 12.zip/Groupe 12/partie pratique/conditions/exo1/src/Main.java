import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {
        System.out.println("donner un nombre");
        Scanner saisie = new Scanner(System.in);
        int nb = saisie.nextInt();
        if(nb%2 == 0){
            System.out.println("le nombre est pair");
        }
        else{
            System.out.println("le nombre est impair");}
    }
}
