import java.util.Scanner;

public class ConditionExo4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez le poids du colis en kg : ");
        double poids = scanner.nextDouble();

        double fraisExpedition = calculerFraisExpedition(poids);

        System.out.println("Les frais d'expédition sont : $" + fraisExpedition);

        scanner.close();
    }

    public static double calculerFraisExpedition(double poids) {
        double[] tranchesPoids = {1, 5, 10, 20};
        double[] tarifs = {5.0, 10.0, 15.0, 20.0, 25.0};

        for (int i = 0; i < tranchesPoids.length; i++) {
            if (poids <= tranchesPoids[i]) {
                return tarifs[i];
            }
        }

        return tarifs[tarifs.length - 1] + (poids - tranchesPoids[tranchesPoids.length - 1]) * 2.0;
    }
}
