import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {
        System.out.println("donner trois nombres");
        Scanner saisie = new Scanner(System.in);
        int a = saisie.nextInt();
        int b = saisie.nextInt();
        int c = saisie.nextInt();
        if (a > b & b > c){
            System.out.println("le plus grand est :"+a);
        }
        else if (b > a & a > c){
            System.out.println("le plus grand est :"+b);
        }
        else {
            System.out.println("le plus grand est :"+c);
        }
    }
}