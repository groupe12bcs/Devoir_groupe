import java.util.Scanner;

import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {
        System.out.println("donner votre age");
        Scanner saisie = new Scanner(System.in);
        int age = saisie.nextInt();
        if (age > 18){
            System.out.println("vous etes majeur");}
        else{
            System.out.println("vous etes mineur");
        }
    }
}