import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("donner une table");
        Scanner saisie = new Scanner(System.in);
        int nombre = saisie.nextInt();
        for (int i = 1; i <= 10; i++){
            System.out.println(i+"X"+nombre+"="+(nombre*i));
        }
    }
}