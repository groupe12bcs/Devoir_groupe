import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner saisie = new Scanner(System.in);
        System.out.println("Entrez un nombre : ");

        int nb = saisie.nextInt();

        long factorielle = 1;
        int i = 1;
        do {
            factorielle *=i;
            i++;

        }while (i<=nb);

        System.out.println("La factorielle de " +nb + "est : "+factorielle);

    }
}
