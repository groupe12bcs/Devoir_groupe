public class Main {
    public static void main(String[] args) {
        int i = 1;
        int som = 0;
        while (i <= 100){
            som +=i;
            i++;
        }
        System.out.println("la somme des nombres de 1 à 100 est :" +som);
    }
}
